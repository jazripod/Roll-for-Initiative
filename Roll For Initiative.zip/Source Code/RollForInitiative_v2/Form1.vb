﻿Public Class frmInitiativeTracker
    Private mName As String
    Private mInitiative As Integer
    Private mGreatestIndex As Integer
    Private mGreatestInitiative As Integer
    Private mGreatestName As String
    Private mBattleIsActive As Boolean = False
    Private mBattleListTracker As Integer = -1
    Private mIndexDecrease As Integer

    '===============================================================
    'Data validation block
    '   - Checks if data has been entered for all fields
    '   - Checks if data in Initiative and Health can be parsed to an integer
    '   - Checks if Initiative and health are greater than 0
    '===============================================================
    Private Function ValidateData()
        If txtName.Text = "" Then
            DisplayError("Be sure you entered a name.")
            txtName.Focus()
            Return False
        Else
            mName = txtName.Text
        End If

        If txtInitiative.Text = "" Then
            DisplayError("Be sure you entered an initiative value.")
            txtInitiative.Focus()
            Return False
        End If

        If Integer.TryParse(txtInitiative.Text, mInitiative) = False Then
            DisplayError("Invalid input for Initiative. Make sure you enter a real number.")
            txtInitiative.Focus()
            Return False
        Else
            mInitiative = Integer.Parse(txtInitiative.Text)
        End If

        If mInitiative <= 0 Then
            DisplayError("The initiative value must be greater than 0.")
            txtInitiative.Focus()
            Return False
        End If

        Return True
    End Function

    'Clears input boxes
    Private Sub ClearInput()
        txtName.Clear()
        txtInitiative.Clear()
    End Sub

    'Clears out the arrays
    Private Sub ClearArray()
        ReDim gBattleList(-1)
        gNameList.Clear()
        gInitiativeList.Clear()
    End Sub

    'Runs data validation, adds the entered data to their respective arrays, and clears out inputs
    Private Sub btnAddToList_Click(sender As Object, e As EventArgs) Handles btnAddToList.Click

        If mBattleIsActive = False Then
            If ValidateData() = False Then
                Exit Sub
            End If

            gIndex = gIndex + 1
            gNameList.Add(mName)
            gInitiativeList.Add(mInitiative)

            ClearInput()
        Else
            DisplayError("You can't add anyone to the Initiative order. A battle is already active.")
            Exit Sub
        End If
    End Sub


    'Activates Battle Mode, begins the sorting process by finding the entry with the highest initiative
    'and puts them in the first index of the Battle List array.
    Private Sub btnBeginBattle_Click(sender As Object, e As EventArgs) Handles btnBeginBattle.Click
        If gIndex = -1 Then
            DisplayError("Your battle list is empty. You can't start the battle with an empty battle list.")
            Exit Sub
        End If

        If mBattleIsActive = False Then
            mBattleIsActive = True
            mGreatestInitiative = 0
            mIndexDecrease = gIndex

            For Ctr = 0 To mIndexDecrease Step 1
                For i = 0 To mIndexDecrease Step 1
                    If gInitiativeList(i) > mGreatestInitiative Then
                        mGreatestInitiative = gInitiativeList(i)
                        mGreatestName = gNameList(i)
                    End If
                Next

                ReDim Preserve gBattleList(gBattleListIndex)
                gBattleList(gBattleListIndex).Name = mGreatestName
                gBattleList(gBattleListIndex).Initiative = mGreatestInitiative

                gInitiativeList.Remove(mGreatestInitiative)
                gNameList.Remove(mGreatestName)

                mGreatestInitiative = 0
                mIndexDecrease = mIndexDecrease - 1
                gBattleListIndex = gBattleListIndex + 1
            Next
            lblOutput.Text = "The battle has begun! Click 'Next' to move through the initiative order."
        Else
            DisplayError("The battle has already begun! Finish this fight before starting a new one.")
            Exit Sub
        End If
    End Sub

    'Goes through the initiative. Loops back to the begining of the initiative.
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        mBattleListTracker = mBattleListTracker + 1

        If mBattleIsActive = True Then
            If mBattleListTracker > gIndex Then
                mBattleListTracker = 0
                lblOutput.Text = "It is now " + gBattleList(mBattleListTracker).Name + "'s turn."
            Else
                lblOutput.Text = "It is now " + gBattleList(mBattleListTracker).Name + "'s turn."
            End If
        Else
            DisplayError("You're not in a battle. Add some characters to the initiative, then click Begin Battle.")
            Exit Sub
        End If
    End Sub

    'Clears everyting and resets program
    Private Sub btnEndBattle_Click(sender As Object, e As EventArgs) Handles btnEndBattle.Click
        mBattleIsActive = False
        mBattleListTracker = -1
        gIndex = -1
        gBattleListIndex = 0
        ClearInput()
        ClearArray()
        lblOutput.Text = ""
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearInput()
    End Sub

    'Closes program
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
    '
    '
    '
    '
    '
    '
    '
    '
    'Health Tracker
    '=================================================================================================================
    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP1.Text)
        HP = HP + 1
        txtHP1.Text = HP.ToString()
    End Sub

    Private Sub Button30_Click(sender As Object, e As EventArgs) Handles Button30.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP1.Text)
        HP = HP + 5
        txtHP1.Text = HP.ToString()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP1.Text)
        HP = HP - 1
        txtHP1.Text = HP.ToString()
    End Sub

    Private Sub Button40_Click(sender As Object, e As EventArgs) Handles Button40.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP1.Text)
        HP = HP - 5
        txtHP1.Text = HP.ToString()
    End Sub

    '==============================================================================================================
    Private Sub Button39_Click(sender As Object, e As EventArgs) Handles Button39.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP2.Text)
        HP = HP - 5
        txtHP2.Text = HP.ToString()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP2.Text)
        HP = HP - 1
        txtHP2.Text = HP.ToString()
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP2.Text)
        HP = HP + 1
        txtHP2.Text = HP.ToString()
    End Sub

    Private Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP2.Text)
        HP = HP + 5
        txtHP2.Text = HP.ToString()
    End Sub

    '=================================================================================================================
    Private Sub Button38_Click(sender As Object, e As EventArgs) Handles Button38.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP3.Text)
        HP = HP - 5
        txtHP3.Text = HP.ToString()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP3.Text)
        HP = HP - 1
        txtHP3.Text = HP.ToString()
    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP3.Text)
        HP = HP + 1
        txtHP3.Text = HP.ToString()
    End Sub

    Private Sub Button28_Click(sender As Object, e As EventArgs) Handles Button28.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP3.Text)
        HP = HP + 5
        txtHP3.Text = HP.ToString()
    End Sub

    '==================================================================================================================
    Private Sub Button37_Click(sender As Object, e As EventArgs) Handles Button37.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP4.Text)
        HP = HP - 5
        txtHP4.Text = HP.ToString()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP4.Text)
        HP = HP - 1
        txtHP4.Text = HP.ToString()
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP4.Text)
        HP = HP + 1
        txtHP4.Text = HP.ToString()
    End Sub

    Private Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP4.Text)
        HP = HP + 5
        txtHP4.Text = HP.ToString()
    End Sub

    '=================================================================================================================
    Private Sub Button36_Click(sender As Object, e As EventArgs) Handles Button36.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP5.Text)
        HP = HP - 5
        txtHP5.Text = HP.ToString()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP5.Text)
        HP = HP - 1
        txtHP5.Text = HP.ToString()
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP5.Text)
        HP = HP + 1
        txtHP5.Text = HP.ToString()
    End Sub

    Private Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP5.Text)
        HP = HP + 5
        txtHP5.Text = HP.ToString()
    End Sub

    '=================================================================================================================
    Private Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP6.Text)
        HP = HP - 5
        txtHP6.Text = HP.ToString()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP6.Text)
        HP = HP - 1
        txtHP6.Text = HP.ToString()
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP6.Text)
        HP = HP + 1
        txtHP6.Text = HP.ToString()
    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP6.Text)
        HP = HP + 5
        txtHP6.Text = HP.ToString()
    End Sub

    '==================================================================================================================
    Private Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP7.Text)
        HP = HP - 5
        txtHP7.Text = HP.ToString()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP7.Text)
        HP = HP - 1
        txtHP7.Text = HP.ToString()
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP7.Text)
        HP = HP + 1
        txtHP7.Text = HP.ToString()
    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP7.Text)
        HP = HP + 5
        txtHP7.Text = HP.ToString()
    End Sub

    '=================================================================================================================
    Private Sub Button33_Click(sender As Object, e As EventArgs) Handles Button33.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP8.Text)
        HP = HP - 5
        txtHP8.Text = HP.ToString()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP8.Text)
        HP = HP - 1
        txtHP8.Text = HP.ToString()
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP8.Text)
        HP = HP + 1
        txtHP8.Text = HP.ToString()
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP8.Text)
        HP = HP + 5
        txtHP8.Text = HP.ToString()
    End Sub

    '=================================================================================================================
    Private Sub Button32_Click(sender As Object, e As EventArgs) Handles Button32.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP9.Text)
        HP = HP - 5
        txtHP9.Text = HP.ToString()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP9.Text)
        HP = HP - 1
        txtHP9.Text = HP.ToString()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP9.Text)
        HP = HP + 1
        txtHP9.Text = HP.ToString()
    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP9.Text)
        HP = HP + 5
        txtHP9.Text = HP.ToString()
    End Sub

    '=================================================================================================================
    Private Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP10.Text)
        HP = HP - 5
        txtHP10.Text = HP.ToString()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP10.Text)
        HP = HP - 1
        txtHP10.Text = HP.ToString()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP10.Text)
        HP = HP + 1
        txtHP10.Text = HP.ToString()
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        Dim HP As Integer
        HP = Integer.Parse(txtHP10.Text)
        HP = HP + 5
        txtHP10.Text = HP.ToString()
    End Sub

    Private Sub btnClearHP_Click(sender As Object, e As EventArgs) Handles btnClearHP.Click
        txtHPName1.Clear()
        txtHPName2.Clear()
        txtHPName3.Clear()
        txtHPName4.Clear()
        txtHPName5.Clear()
        txtHPName6.Clear()
        txtHPName7.Clear()
        txtHPName8.Clear()
        txtHPName9.Clear()
        txtHPName10.Clear()

        txtHP1.Text = "0"
        txtHP2.Text = "0"
        txtHP3.Text = "0"
        txtHP4.Text = "0"
        txtHP5.Text = "0"
        txtHP6.Text = "0"
        txtHP7.Text = "0"
        txtHP8.Text = "0"
        txtHP9.Text = "0"
        txtHP10.Text = "0"
    End Sub
End Class
