﻿Module Globals
    Public gNames() As String
    Public gInitiative() As Integer
    Public gIndex As Integer = -1
    Public gBattleListIndex As Integer = 0
    Public gBattleList() As List

    Public gNameList As New ArrayList()
    Public gInitiativeList As New ArrayList()

    Public Structure List
        Dim Name As String
        Dim Initiative As Integer
    End Structure

    Public Sub DisplayError(Message)
        MessageBox.Show(Message, "Looks like you rolled a Natural 1!", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

End Module