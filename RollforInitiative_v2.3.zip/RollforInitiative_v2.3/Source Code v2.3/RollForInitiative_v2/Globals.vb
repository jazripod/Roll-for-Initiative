﻿Module Globals
    'Global variables
    Public gNames() As String
    Public gInitiative() As Integer
    Public gIndex As Integer = -1
    Public gBattleListIndex As Integer = 0
    Public gBattleList() As List

    'Array lists. Contain names and initiative values for the Initiative tracker
    Public gNameList As New ArrayList()
    Public gInitiativeList As New ArrayList()

    Public Structure List
        Dim Name As String
        Dim Initiative As Integer
    End Structure

    'General error message
    Public Sub DisplayError(Message)
        MessageBox.Show(Message, "Looks like you rolled a Natural 1!", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    'Validates data entered for Initiative Tracker
    Public Function DataValidation(varName As String, varInitiative As String)
        If frmInitiativeTracker.txtName.Text = "" Then
            DisplayError("Be sure you entered a name.")
            frmInitiativeTracker.txtName.Focus()
            Return False
        End If

        If frmInitiativeTracker.txtInitiative.Text = "" Then
            DisplayError("Be sure you entered an initiative value.")
            frmInitiativeTracker.txtInitiative.Focus()
            Return False
        End If

        If Integer.TryParse(frmInitiativeTracker.txtInitiative.Text, varInitiative) = False Then
            DisplayError("Invalid input for Initiative. Make sure you enter a real number.")
            frmInitiativeTracker.txtInitiative.Focus()
            Return False
        End If

        If varInitiative <= 0 Then
            DisplayError("The initiative value must be greater than 0.")
            frmInitiativeTracker.txtInitiative.Focus()
            Return False
        End If

        Return True
    End Function

    'Dice roller. Takes in number of dice, dice type, and modifiers, then gets a random number based on the 
    'type of dice and number of dice. Returns final value after mods
    Public Function DiceRoll(numDice As Integer, diceSize As Integer, isPlus As Boolean, isSub As Boolean, diceMod As Integer) As Integer
        Dim Generator As New Random
        Dim Result As Integer

        Result = Generator.Next(numDice, (numDice * diceSize) + 1)

        If isPlus = True Then
            Result = Result + diceMod
        ElseIf isSub = True Then
            Result = Result - diceMod
        End If

        Return Result
    End Function
End Module