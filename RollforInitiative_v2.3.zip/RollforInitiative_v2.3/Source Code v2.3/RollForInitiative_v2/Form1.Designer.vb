﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInitiativeTracker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblInitiative = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtInitiative = New System.Windows.Forms.TextBox()
        Me.btnAddToList = New System.Windows.Forms.Button()
        Me.btnBeginBattle = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnEndBattle = New System.Windows.Forms.Button()
        Me.tabMain = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.btnExitHP = New System.Windows.Forms.Button()
        Me.btnClearHP = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtHP10 = New System.Windows.Forms.TextBox()
        Me.txtHPName10 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtHP9 = New System.Windows.Forms.TextBox()
        Me.txtHPName9 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtHP8 = New System.Windows.Forms.TextBox()
        Me.txtHPName8 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtHP7 = New System.Windows.Forms.TextBox()
        Me.txtHPName7 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtHP6 = New System.Windows.Forms.TextBox()
        Me.txtHPName6 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtHP5 = New System.Windows.Forms.TextBox()
        Me.txtHPName5 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtHP4 = New System.Windows.Forms.TextBox()
        Me.txtHPName4 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtHP3 = New System.Windows.Forms.TextBox()
        Me.txtHPName3 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtHP2 = New System.Windows.Forms.TextBox()
        Me.txtHPName2 = New System.Windows.Forms.TextBox()
        Me.lbl01 = New System.Windows.Forms.Label()
        Me.txtHP1 = New System.Windows.Forms.TextBox()
        Me.txtHPName1 = New System.Windows.Forms.TextBox()
        Me.lblHealth = New System.Windows.Forms.Label()
        Me.lblNameHealth = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.btnClearDice = New System.Windows.Forms.Button()
        Me.btnExitDice = New System.Windows.Forms.Button()
        Me.lblResults = New System.Windows.Forms.Label()
        Me.lblMod = New System.Windows.Forms.Label()
        Me.lblSubMod = New System.Windows.Forms.Label()
        Me.lblAddMod = New System.Windows.Forms.Label()
        Me.lblDice = New System.Windows.Forms.Label()
        Me.lblOutputDice = New System.Windows.Forms.Label()
        Me.txtD100Mod = New System.Windows.Forms.TextBox()
        Me.txtD20Mod = New System.Windows.Forms.TextBox()
        Me.txtD12Mod = New System.Windows.Forms.TextBox()
        Me.txtD10Mod = New System.Windows.Forms.TextBox()
        Me.txtD8Mod = New System.Windows.Forms.TextBox()
        Me.txtD6Mod = New System.Windows.Forms.TextBox()
        Me.txtD4Mod = New System.Windows.Forms.TextBox()
        Me.radD100Sub = New System.Windows.Forms.RadioButton()
        Me.radD20Sub = New System.Windows.Forms.RadioButton()
        Me.radD12Sub = New System.Windows.Forms.RadioButton()
        Me.radD10Sub = New System.Windows.Forms.RadioButton()
        Me.radD8Sub = New System.Windows.Forms.RadioButton()
        Me.radD6Sub = New System.Windows.Forms.RadioButton()
        Me.radD4Sub = New System.Windows.Forms.RadioButton()
        Me.radD100Plus = New System.Windows.Forms.RadioButton()
        Me.radD20Plus = New System.Windows.Forms.RadioButton()
        Me.radD12Plus = New System.Windows.Forms.RadioButton()
        Me.radD10Plus = New System.Windows.Forms.RadioButton()
        Me.RadD8Plus = New System.Windows.Forms.RadioButton()
        Me.radD6Plus = New System.Windows.Forms.RadioButton()
        Me.radD4Plus = New System.Windows.Forms.RadioButton()
        Me.lblDivider = New System.Windows.Forms.Label()
        Me.btnRollD100 = New System.Windows.Forms.Button()
        Me.btnRollD20 = New System.Windows.Forms.Button()
        Me.btnRollD12 = New System.Windows.Forms.Button()
        Me.btnRollD10 = New System.Windows.Forms.Button()
        Me.btnRollD8 = New System.Windows.Forms.Button()
        Me.btnRollD6 = New System.Windows.Forms.Button()
        Me.btnRollD4 = New System.Windows.Forms.Button()
        Me.lblD100 = New System.Windows.Forms.Label()
        Me.lblD20 = New System.Windows.Forms.Label()
        Me.lblD12 = New System.Windows.Forms.Label()
        Me.lblD10 = New System.Windows.Forms.Label()
        Me.lblD8 = New System.Windows.Forms.Label()
        Me.lblD6 = New System.Windows.Forms.Label()
        Me.lblD4 = New System.Windows.Forms.Label()
        Me.txtD100 = New System.Windows.Forms.TextBox()
        Me.txtD20 = New System.Windows.Forms.TextBox()
        Me.txtD12 = New System.Windows.Forms.TextBox()
        Me.txtD10 = New System.Windows.Forms.TextBox()
        Me.txtD8 = New System.Windows.Forms.TextBox()
        Me.txtD6 = New System.Windows.Forms.TextBox()
        Me.txtD4 = New System.Windows.Forms.TextBox()
        Me.tabMain.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblName.Location = New System.Drawing.Point(183, 18)
        Me.lblName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(64, 25)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name"
        '
        'lblInitiative
        '
        Me.lblInitiative.AutoSize = True
        Me.lblInitiative.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblInitiative.Location = New System.Drawing.Point(482, 17)
        Me.lblInitiative.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblInitiative.Name = "lblInitiative"
        Me.lblInitiative.Size = New System.Drawing.Size(82, 25)
        Me.lblInitiative.TabIndex = 1
        Me.lblInitiative.Text = "Initiative"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(34, 48)
        Me.txtName.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(365, 26)
        Me.txtName.TabIndex = 2
        '
        'txtInitiative
        '
        Me.txtInitiative.Location = New System.Drawing.Point(453, 48)
        Me.txtInitiative.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtInitiative.Name = "txtInitiative"
        Me.txtInitiative.Size = New System.Drawing.Size(140, 26)
        Me.txtInitiative.TabIndex = 3
        '
        'btnAddToList
        '
        Me.btnAddToList.Location = New System.Drawing.Point(614, 33)
        Me.btnAddToList.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnAddToList.Name = "btnAddToList"
        Me.btnAddToList.Size = New System.Drawing.Size(142, 57)
        Me.btnAddToList.TabIndex = 4
        Me.btnAddToList.Text = "Add to Initiative Order"
        Me.btnAddToList.UseVisualStyleBackColor = True
        '
        'btnBeginBattle
        '
        Me.btnBeginBattle.Location = New System.Drawing.Point(614, 153)
        Me.btnBeginBattle.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBeginBattle.Name = "btnBeginBattle"
        Me.btnBeginBattle.Size = New System.Drawing.Size(142, 88)
        Me.btnBeginBattle.TabIndex = 5
        Me.btnBeginBattle.Text = "Begin Battle"
        Me.btnBeginBattle.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(613, 388)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(142, 38)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(614, 509)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(142, 40)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblOutput
        '
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblOutput.Location = New System.Drawing.Point(34, 153)
        Me.lblOutput.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(559, 323)
        Me.lblOutput.TabIndex = 8
        Me.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(613, 286)
        Me.btnNext.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(142, 40)
        Me.btnNext.TabIndex = 9
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnEndBattle
        '
        Me.btnEndBattle.Location = New System.Drawing.Point(614, 336)
        Me.btnEndBattle.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnEndBattle.Name = "btnEndBattle"
        Me.btnEndBattle.Size = New System.Drawing.Size(142, 40)
        Me.btnEndBattle.TabIndex = 12
        Me.btnEndBattle.Text = "End Battle"
        Me.btnEndBattle.UseVisualStyleBackColor = True
        '
        'tabMain
        '
        Me.tabMain.Controls.Add(Me.TabPage1)
        Me.tabMain.Controls.Add(Me.TabPage2)
        Me.tabMain.Controls.Add(Me.TabPage3)
        Me.tabMain.Location = New System.Drawing.Point(8, 5)
        Me.tabMain.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabMain.Name = "tabMain"
        Me.tabMain.SelectedIndex = 0
        Me.tabMain.Size = New System.Drawing.Size(809, 592)
        Me.tabMain.TabIndex = 13
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.Controls.Add(Me.btnAddToList)
        Me.TabPage1.Controls.Add(Me.btnEndBattle)
        Me.TabPage1.Controls.Add(Me.lblName)
        Me.TabPage1.Controls.Add(Me.lblInitiative)
        Me.TabPage1.Controls.Add(Me.txtName)
        Me.TabPage1.Controls.Add(Me.btnNext)
        Me.TabPage1.Controls.Add(Me.txtInitiative)
        Me.TabPage1.Controls.Add(Me.lblOutput)
        Me.TabPage1.Controls.Add(Me.btnBeginBattle)
        Me.TabPage1.Controls.Add(Me.btnExit)
        Me.TabPage1.Controls.Add(Me.btnClear)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage1.Size = New System.Drawing.Size(801, 559)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Initiative Tracker"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.btnExitHP)
        Me.TabPage2.Controls.Add(Me.btnClearHP)
        Me.TabPage2.Controls.Add(Me.Button31)
        Me.TabPage2.Controls.Add(Me.Button32)
        Me.TabPage2.Controls.Add(Me.Button33)
        Me.TabPage2.Controls.Add(Me.Button34)
        Me.TabPage2.Controls.Add(Me.Button35)
        Me.TabPage2.Controls.Add(Me.Button36)
        Me.TabPage2.Controls.Add(Me.Button37)
        Me.TabPage2.Controls.Add(Me.Button38)
        Me.TabPage2.Controls.Add(Me.Button39)
        Me.TabPage2.Controls.Add(Me.Button40)
        Me.TabPage2.Controls.Add(Me.Button21)
        Me.TabPage2.Controls.Add(Me.Button22)
        Me.TabPage2.Controls.Add(Me.Button23)
        Me.TabPage2.Controls.Add(Me.Button24)
        Me.TabPage2.Controls.Add(Me.Button25)
        Me.TabPage2.Controls.Add(Me.Button26)
        Me.TabPage2.Controls.Add(Me.Button27)
        Me.TabPage2.Controls.Add(Me.Button28)
        Me.TabPage2.Controls.Add(Me.Button29)
        Me.TabPage2.Controls.Add(Me.Button30)
        Me.TabPage2.Controls.Add(Me.Button11)
        Me.TabPage2.Controls.Add(Me.Button12)
        Me.TabPage2.Controls.Add(Me.Button13)
        Me.TabPage2.Controls.Add(Me.Button14)
        Me.TabPage2.Controls.Add(Me.Button15)
        Me.TabPage2.Controls.Add(Me.Button16)
        Me.TabPage2.Controls.Add(Me.Button17)
        Me.TabPage2.Controls.Add(Me.Button18)
        Me.TabPage2.Controls.Add(Me.Button19)
        Me.TabPage2.Controls.Add(Me.Button20)
        Me.TabPage2.Controls.Add(Me.Button10)
        Me.TabPage2.Controls.Add(Me.Button9)
        Me.TabPage2.Controls.Add(Me.Button8)
        Me.TabPage2.Controls.Add(Me.Button7)
        Me.TabPage2.Controls.Add(Me.Button6)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.Button4)
        Me.TabPage2.Controls.Add(Me.Button3)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Controls.Add(Me.Button1)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.txtHP10)
        Me.TabPage2.Controls.Add(Me.txtHPName10)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.txtHP9)
        Me.TabPage2.Controls.Add(Me.txtHPName9)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.txtHP8)
        Me.TabPage2.Controls.Add(Me.txtHPName8)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.txtHP7)
        Me.TabPage2.Controls.Add(Me.txtHPName7)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.txtHP6)
        Me.TabPage2.Controls.Add(Me.txtHPName6)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.txtHP5)
        Me.TabPage2.Controls.Add(Me.txtHPName5)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.txtHP4)
        Me.TabPage2.Controls.Add(Me.txtHPName4)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.txtHP3)
        Me.TabPage2.Controls.Add(Me.txtHPName3)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.txtHP2)
        Me.TabPage2.Controls.Add(Me.txtHPName2)
        Me.TabPage2.Controls.Add(Me.lbl01)
        Me.TabPage2.Controls.Add(Me.txtHP1)
        Me.TabPage2.Controls.Add(Me.txtHPName1)
        Me.TabPage2.Controls.Add(Me.lblHealth)
        Me.TabPage2.Controls.Add(Me.lblNameHealth)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TabPage2.Size = New System.Drawing.Size(801, 559)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Health Tracker"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'btnExitHP
        '
        Me.btnExitHP.Location = New System.Drawing.Point(609, 514)
        Me.btnExitHP.Name = "btnExitHP"
        Me.btnExitHP.Size = New System.Drawing.Size(136, 37)
        Me.btnExitHP.TabIndex = 74
        Me.btnExitHP.Text = "Exit"
        Me.btnExitHP.UseVisualStyleBackColor = True
        '
        'btnClearHP
        '
        Me.btnClearHP.Location = New System.Drawing.Point(458, 514)
        Me.btnClearHP.Name = "btnClearHP"
        Me.btnClearHP.Size = New System.Drawing.Size(136, 37)
        Me.btnClearHP.TabIndex = 73
        Me.btnClearHP.Text = "Clear"
        Me.btnClearHP.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(424, 442)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(40, 33)
        Me.Button31.TabIndex = 72
        Me.Button31.Text = "-5"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(424, 396)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(40, 33)
        Me.Button32.TabIndex = 71
        Me.Button32.Text = "-5"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(424, 353)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(40, 33)
        Me.Button33.TabIndex = 70
        Me.Button33.Text = "-5"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(424, 312)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(40, 33)
        Me.Button34.TabIndex = 69
        Me.Button34.Text = "-5"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(424, 267)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(40, 33)
        Me.Button35.TabIndex = 68
        Me.Button35.Text = "-5"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(424, 220)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(40, 33)
        Me.Button36.TabIndex = 67
        Me.Button36.Text = "-5"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(424, 181)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(40, 33)
        Me.Button37.TabIndex = 66
        Me.Button37.Text = "-5"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(424, 136)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(40, 33)
        Me.Button38.TabIndex = 65
        Me.Button38.Text = "-5"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.Location = New System.Drawing.Point(424, 95)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(40, 33)
        Me.Button39.TabIndex = 64
        Me.Button39.Text = "-5"
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.Location = New System.Drawing.Point(424, 53)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(40, 33)
        Me.Button40.TabIndex = 63
        Me.Button40.Text = "-5"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(715, 442)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(40, 33)
        Me.Button21.TabIndex = 62
        Me.Button21.Text = "+5"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(715, 396)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(40, 33)
        Me.Button22.TabIndex = 61
        Me.Button22.Text = "+5"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(715, 353)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(40, 33)
        Me.Button23.TabIndex = 60
        Me.Button23.Text = "+5"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(715, 312)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(40, 33)
        Me.Button24.TabIndex = 59
        Me.Button24.Text = "+5"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(715, 267)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(40, 33)
        Me.Button25.TabIndex = 58
        Me.Button25.Text = "+5"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(715, 220)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(40, 33)
        Me.Button26.TabIndex = 57
        Me.Button26.Text = "+5"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(715, 181)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(40, 33)
        Me.Button27.TabIndex = 56
        Me.Button27.Text = "+5"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(715, 136)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(40, 33)
        Me.Button28.TabIndex = 55
        Me.Button28.Text = "+5"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(715, 95)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(40, 33)
        Me.Button29.TabIndex = 54
        Me.Button29.Text = "+5"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(715, 53)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(40, 33)
        Me.Button30.TabIndex = 53
        Me.Button30.Text = "+5"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(669, 442)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(40, 33)
        Me.Button11.TabIndex = 52
        Me.Button11.Text = "+1"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(669, 396)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(40, 33)
        Me.Button12.TabIndex = 51
        Me.Button12.Text = "+1"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(669, 353)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(40, 33)
        Me.Button13.TabIndex = 50
        Me.Button13.Text = "+1"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(669, 312)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(40, 33)
        Me.Button14.TabIndex = 49
        Me.Button14.Text = "+1"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(669, 267)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(40, 33)
        Me.Button15.TabIndex = 48
        Me.Button15.Text = "+1"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(669, 220)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(40, 33)
        Me.Button16.TabIndex = 47
        Me.Button16.Text = "+1"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(669, 181)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(40, 33)
        Me.Button17.TabIndex = 46
        Me.Button17.Text = "+1"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(669, 136)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(40, 33)
        Me.Button18.TabIndex = 45
        Me.Button18.Text = "+1"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(669, 95)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(40, 33)
        Me.Button19.TabIndex = 44
        Me.Button19.Text = "+1"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(669, 53)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(40, 33)
        Me.Button20.TabIndex = 43
        Me.Button20.Text = "+1"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(470, 442)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(40, 33)
        Me.Button10.TabIndex = 42
        Me.Button10.Text = "-1"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(470, 396)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(40, 33)
        Me.Button9.TabIndex = 41
        Me.Button9.Text = "-1"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(470, 353)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(40, 33)
        Me.Button8.TabIndex = 40
        Me.Button8.Text = "-1"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(470, 312)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(40, 33)
        Me.Button7.TabIndex = 39
        Me.Button7.Text = "-1"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(470, 267)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(40, 33)
        Me.Button6.TabIndex = 38
        Me.Button6.Text = "-1"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(470, 220)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(40, 33)
        Me.Button5.TabIndex = 37
        Me.Button5.Text = "-1"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(470, 181)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(40, 33)
        Me.Button4.TabIndex = 36
        Me.Button4.Text = "-1"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(470, 136)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(40, 33)
        Me.Button3.TabIndex = 35
        Me.Button3.Text = "-1"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(470, 95)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(40, 33)
        Me.Button2.TabIndex = 34
        Me.Button2.Text = "-1"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(470, 53)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(40, 33)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "-1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label9.Location = New System.Drawing.Point(11, 444)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(39, 25)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "10."
        '
        'txtHP10
        '
        Me.txtHP10.Location = New System.Drawing.Point(516, 445)
        Me.txtHP10.Name = "txtHP10"
        Me.txtHP10.Size = New System.Drawing.Size(147, 26)
        Me.txtHP10.TabIndex = 31
        Me.txtHP10.Text = "0"
        Me.txtHP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName10
        '
        Me.txtHPName10.Location = New System.Drawing.Point(54, 443)
        Me.txtHPName10.Name = "txtHPName10"
        Me.txtHPName10.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName10.TabIndex = 30
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label8.Location = New System.Drawing.Point(19, 398)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 25)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "9."
        '
        'txtHP9
        '
        Me.txtHP9.Location = New System.Drawing.Point(516, 399)
        Me.txtHP9.Name = "txtHP9"
        Me.txtHP9.Size = New System.Drawing.Size(147, 26)
        Me.txtHP9.TabIndex = 28
        Me.txtHP9.Text = "0"
        Me.txtHP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName9
        '
        Me.txtHPName9.Location = New System.Drawing.Point(54, 397)
        Me.txtHPName9.Name = "txtHPName9"
        Me.txtHPName9.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName9.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label7.Location = New System.Drawing.Point(19, 357)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 25)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "8."
        '
        'txtHP8
        '
        Me.txtHP8.Location = New System.Drawing.Point(516, 358)
        Me.txtHP8.Name = "txtHP8"
        Me.txtHP8.Size = New System.Drawing.Size(147, 26)
        Me.txtHP8.TabIndex = 25
        Me.txtHP8.Text = "0"
        Me.txtHP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName8
        '
        Me.txtHPName8.Location = New System.Drawing.Point(54, 356)
        Me.txtHPName8.Name = "txtHPName8"
        Me.txtHPName8.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName8.TabIndex = 24
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label6.Location = New System.Drawing.Point(19, 314)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 25)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "7."
        '
        'txtHP7
        '
        Me.txtHP7.Location = New System.Drawing.Point(516, 315)
        Me.txtHP7.Name = "txtHP7"
        Me.txtHP7.Size = New System.Drawing.Size(147, 26)
        Me.txtHP7.TabIndex = 22
        Me.txtHP7.Text = "0"
        Me.txtHP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName7
        '
        Me.txtHPName7.Location = New System.Drawing.Point(54, 313)
        Me.txtHPName7.Name = "txtHPName7"
        Me.txtHPName7.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName7.TabIndex = 21
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label5.Location = New System.Drawing.Point(19, 269)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 25)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "6."
        '
        'txtHP6
        '
        Me.txtHP6.Location = New System.Drawing.Point(516, 270)
        Me.txtHP6.Name = "txtHP6"
        Me.txtHP6.Size = New System.Drawing.Size(147, 26)
        Me.txtHP6.TabIndex = 19
        Me.txtHP6.Text = "0"
        Me.txtHP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName6
        '
        Me.txtHPName6.Location = New System.Drawing.Point(54, 268)
        Me.txtHPName6.Name = "txtHPName6"
        Me.txtHPName6.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName6.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label4.Location = New System.Drawing.Point(19, 224)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 25)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "5."
        '
        'txtHP5
        '
        Me.txtHP5.Location = New System.Drawing.Point(516, 225)
        Me.txtHP5.Name = "txtHP5"
        Me.txtHP5.Size = New System.Drawing.Size(147, 26)
        Me.txtHP5.TabIndex = 16
        Me.txtHP5.Text = "0"
        Me.txtHP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName5
        '
        Me.txtHPName5.Location = New System.Drawing.Point(54, 223)
        Me.txtHPName5.Name = "txtHPName5"
        Me.txtHPName5.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName5.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label3.Location = New System.Drawing.Point(19, 183)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 25)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "4."
        '
        'txtHP4
        '
        Me.txtHP4.Location = New System.Drawing.Point(516, 184)
        Me.txtHP4.Name = "txtHP4"
        Me.txtHP4.Size = New System.Drawing.Size(147, 26)
        Me.txtHP4.TabIndex = 13
        Me.txtHP4.Text = "0"
        Me.txtHP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName4
        '
        Me.txtHPName4.Location = New System.Drawing.Point(54, 182)
        Me.txtHPName4.Name = "txtHPName4"
        Me.txtHPName4.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName4.TabIndex = 12
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label2.Location = New System.Drawing.Point(19, 140)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 25)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "3."
        '
        'txtHP3
        '
        Me.txtHP3.Location = New System.Drawing.Point(516, 141)
        Me.txtHP3.Name = "txtHP3"
        Me.txtHP3.Size = New System.Drawing.Size(147, 26)
        Me.txtHP3.TabIndex = 10
        Me.txtHP3.Text = "0"
        Me.txtHP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName3
        '
        Me.txtHPName3.Location = New System.Drawing.Point(54, 139)
        Me.txtHPName3.Name = "txtHPName3"
        Me.txtHPName3.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName3.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label1.Location = New System.Drawing.Point(19, 97)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 25)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "2."
        '
        'txtHP2
        '
        Me.txtHP2.Location = New System.Drawing.Point(516, 98)
        Me.txtHP2.Name = "txtHP2"
        Me.txtHP2.Size = New System.Drawing.Size(147, 26)
        Me.txtHP2.TabIndex = 7
        Me.txtHP2.Text = "0"
        Me.txtHP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName2
        '
        Me.txtHPName2.Location = New System.Drawing.Point(54, 96)
        Me.txtHPName2.Name = "txtHPName2"
        Me.txtHPName2.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName2.TabIndex = 6
        '
        'lbl01
        '
        Me.lbl01.AutoSize = True
        Me.lbl01.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lbl01.Location = New System.Drawing.Point(19, 55)
        Me.lbl01.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl01.Name = "lbl01"
        Me.lbl01.Size = New System.Drawing.Size(28, 25)
        Me.lbl01.TabIndex = 5
        Me.lbl01.Text = "1."
        '
        'txtHP1
        '
        Me.txtHP1.Location = New System.Drawing.Point(516, 56)
        Me.txtHP1.Name = "txtHP1"
        Me.txtHP1.Size = New System.Drawing.Size(147, 26)
        Me.txtHP1.TabIndex = 4
        Me.txtHP1.Text = "0"
        Me.txtHP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtHPName1
        '
        Me.txtHPName1.Location = New System.Drawing.Point(54, 54)
        Me.txtHPName1.Name = "txtHPName1"
        Me.txtHPName1.Size = New System.Drawing.Size(319, 26)
        Me.txtHPName1.TabIndex = 3
        '
        'lblHealth
        '
        Me.lblHealth.AutoSize = True
        Me.lblHealth.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblHealth.Location = New System.Drawing.Point(557, 19)
        Me.lblHealth.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHealth.Name = "lblHealth"
        Me.lblHealth.Size = New System.Drawing.Size(68, 25)
        Me.lblHealth.TabIndex = 2
        Me.lblHealth.Text = "Health"
        '
        'lblNameHealth
        '
        Me.lblNameHealth.AutoSize = True
        Me.lblNameHealth.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblNameHealth.Location = New System.Drawing.Point(175, 17)
        Me.lblNameHealth.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblNameHealth.Name = "lblNameHealth"
        Me.lblNameHealth.Size = New System.Drawing.Size(64, 25)
        Me.lblNameHealth.TabIndex = 1
        Me.lblNameHealth.Text = "Name"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.btnClearDice)
        Me.TabPage3.Controls.Add(Me.btnExitDice)
        Me.TabPage3.Controls.Add(Me.lblResults)
        Me.TabPage3.Controls.Add(Me.lblMod)
        Me.TabPage3.Controls.Add(Me.lblSubMod)
        Me.TabPage3.Controls.Add(Me.lblAddMod)
        Me.TabPage3.Controls.Add(Me.lblDice)
        Me.TabPage3.Controls.Add(Me.lblOutputDice)
        Me.TabPage3.Controls.Add(Me.txtD100Mod)
        Me.TabPage3.Controls.Add(Me.txtD20Mod)
        Me.TabPage3.Controls.Add(Me.txtD12Mod)
        Me.TabPage3.Controls.Add(Me.txtD10Mod)
        Me.TabPage3.Controls.Add(Me.txtD8Mod)
        Me.TabPage3.Controls.Add(Me.txtD6Mod)
        Me.TabPage3.Controls.Add(Me.txtD4Mod)
        Me.TabPage3.Controls.Add(Me.radD100Sub)
        Me.TabPage3.Controls.Add(Me.radD20Sub)
        Me.TabPage3.Controls.Add(Me.radD12Sub)
        Me.TabPage3.Controls.Add(Me.radD10Sub)
        Me.TabPage3.Controls.Add(Me.radD8Sub)
        Me.TabPage3.Controls.Add(Me.radD6Sub)
        Me.TabPage3.Controls.Add(Me.radD4Sub)
        Me.TabPage3.Controls.Add(Me.radD100Plus)
        Me.TabPage3.Controls.Add(Me.radD20Plus)
        Me.TabPage3.Controls.Add(Me.radD12Plus)
        Me.TabPage3.Controls.Add(Me.radD10Plus)
        Me.TabPage3.Controls.Add(Me.RadD8Plus)
        Me.TabPage3.Controls.Add(Me.radD6Plus)
        Me.TabPage3.Controls.Add(Me.radD4Plus)
        Me.TabPage3.Controls.Add(Me.lblDivider)
        Me.TabPage3.Controls.Add(Me.btnRollD100)
        Me.TabPage3.Controls.Add(Me.btnRollD20)
        Me.TabPage3.Controls.Add(Me.btnRollD12)
        Me.TabPage3.Controls.Add(Me.btnRollD10)
        Me.TabPage3.Controls.Add(Me.btnRollD8)
        Me.TabPage3.Controls.Add(Me.btnRollD6)
        Me.TabPage3.Controls.Add(Me.btnRollD4)
        Me.TabPage3.Controls.Add(Me.lblD100)
        Me.TabPage3.Controls.Add(Me.lblD20)
        Me.TabPage3.Controls.Add(Me.lblD12)
        Me.TabPage3.Controls.Add(Me.lblD10)
        Me.TabPage3.Controls.Add(Me.lblD8)
        Me.TabPage3.Controls.Add(Me.lblD6)
        Me.TabPage3.Controls.Add(Me.lblD4)
        Me.TabPage3.Controls.Add(Me.txtD100)
        Me.TabPage3.Controls.Add(Me.txtD20)
        Me.TabPage3.Controls.Add(Me.txtD12)
        Me.TabPage3.Controls.Add(Me.txtD10)
        Me.TabPage3.Controls.Add(Me.txtD8)
        Me.TabPage3.Controls.Add(Me.txtD6)
        Me.TabPage3.Controls.Add(Me.txtD4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(801, 559)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Dice Roller"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'btnClearDice
        '
        Me.btnClearDice.Location = New System.Drawing.Point(447, 517)
        Me.btnClearDice.Name = "btnClearDice"
        Me.btnClearDice.Size = New System.Drawing.Size(134, 34)
        Me.btnClearDice.TabIndex = 51
        Me.btnClearDice.Text = "Clear"
        Me.btnClearDice.UseVisualStyleBackColor = True
        '
        'btnExitDice
        '
        Me.btnExitDice.Location = New System.Drawing.Point(605, 517)
        Me.btnExitDice.Name = "btnExitDice"
        Me.btnExitDice.Size = New System.Drawing.Size(134, 34)
        Me.btnExitDice.TabIndex = 50
        Me.btnExitDice.Text = "Exit"
        Me.btnExitDice.UseVisualStyleBackColor = True
        '
        'lblResults
        '
        Me.lblResults.AutoSize = True
        Me.lblResults.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblResults.Location = New System.Drawing.Point(621, 42)
        Me.lblResults.Name = "lblResults"
        Me.lblResults.Size = New System.Drawing.Size(76, 25)
        Me.lblResults.TabIndex = 49
        Me.lblResults.Text = "Results"
        '
        'lblMod
        '
        Me.lblMod.AutoSize = True
        Me.lblMod.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblMod.Location = New System.Drawing.Point(309, 42)
        Me.lblMod.Name = "lblMod"
        Me.lblMod.Size = New System.Drawing.Size(81, 25)
        Me.lblMod.TabIndex = 48
        Me.lblMod.Text = "Modifier"
        '
        'lblSubMod
        '
        Me.lblSubMod.AutoSize = True
        Me.lblSubMod.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblSubMod.Location = New System.Drawing.Point(238, 42)
        Me.lblSubMod.Name = "lblSubMod"
        Me.lblSubMod.Size = New System.Drawing.Size(19, 25)
        Me.lblSubMod.TabIndex = 47
        Me.lblSubMod.Text = "-"
        '
        'lblAddMod
        '
        Me.lblAddMod.AutoSize = True
        Me.lblAddMod.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblAddMod.Location = New System.Drawing.Point(196, 42)
        Me.lblAddMod.Name = "lblAddMod"
        Me.lblAddMod.Size = New System.Drawing.Size(24, 25)
        Me.lblAddMod.TabIndex = 46
        Me.lblAddMod.Text = "+"
        '
        'lblDice
        '
        Me.lblDice.AutoSize = True
        Me.lblDice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblDice.Location = New System.Drawing.Point(41, 42)
        Me.lblDice.Name = "lblDice"
        Me.lblDice.Size = New System.Drawing.Size(51, 25)
        Me.lblDice.TabIndex = 45
        Me.lblDice.Text = "Dice"
        '
        'lblOutputDice
        '
        Me.lblOutputDice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOutputDice.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
        Me.lblOutputDice.Location = New System.Drawing.Point(543, 104)
        Me.lblOutputDice.Name = "lblOutputDice"
        Me.lblOutputDice.Size = New System.Drawing.Size(237, 293)
        Me.lblOutputDice.TabIndex = 44
        Me.lblOutputDice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtD100Mod
        '
        Me.txtD100Mod.Location = New System.Drawing.Point(302, 371)
        Me.txtD100Mod.Name = "txtD100Mod"
        Me.txtD100Mod.Size = New System.Drawing.Size(100, 26)
        Me.txtD100Mod.TabIndex = 43
        Me.txtD100Mod.Text = "0"
        Me.txtD100Mod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD20Mod
        '
        Me.txtD20Mod.Location = New System.Drawing.Point(302, 328)
        Me.txtD20Mod.Name = "txtD20Mod"
        Me.txtD20Mod.Size = New System.Drawing.Size(100, 26)
        Me.txtD20Mod.TabIndex = 42
        Me.txtD20Mod.Text = "0"
        Me.txtD20Mod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD12Mod
        '
        Me.txtD12Mod.Location = New System.Drawing.Point(302, 280)
        Me.txtD12Mod.Name = "txtD12Mod"
        Me.txtD12Mod.Size = New System.Drawing.Size(100, 26)
        Me.txtD12Mod.TabIndex = 41
        Me.txtD12Mod.Text = "0"
        Me.txtD12Mod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD10Mod
        '
        Me.txtD10Mod.Location = New System.Drawing.Point(302, 234)
        Me.txtD10Mod.Name = "txtD10Mod"
        Me.txtD10Mod.Size = New System.Drawing.Size(100, 26)
        Me.txtD10Mod.TabIndex = 40
        Me.txtD10Mod.Text = "0"
        Me.txtD10Mod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD8Mod
        '
        Me.txtD8Mod.Location = New System.Drawing.Point(302, 192)
        Me.txtD8Mod.Name = "txtD8Mod"
        Me.txtD8Mod.Size = New System.Drawing.Size(100, 26)
        Me.txtD8Mod.TabIndex = 39
        Me.txtD8Mod.Text = "0"
        Me.txtD8Mod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD6Mod
        '
        Me.txtD6Mod.Location = New System.Drawing.Point(302, 147)
        Me.txtD6Mod.Name = "txtD6Mod"
        Me.txtD6Mod.Size = New System.Drawing.Size(100, 26)
        Me.txtD6Mod.TabIndex = 38
        Me.txtD6Mod.Text = "0"
        Me.txtD6Mod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD4Mod
        '
        Me.txtD4Mod.Location = New System.Drawing.Point(302, 106)
        Me.txtD4Mod.Name = "txtD4Mod"
        Me.txtD4Mod.Size = New System.Drawing.Size(100, 26)
        Me.txtD4Mod.TabIndex = 37
        Me.txtD4Mod.Text = "0"
        Me.txtD4Mod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'radD100Sub
        '
        Me.radD100Sub.AutoSize = True
        Me.radD100Sub.Location = New System.Drawing.Point(241, 379)
        Me.radD100Sub.Name = "radD100Sub"
        Me.radD100Sub.Size = New System.Drawing.Size(21, 20)
        Me.radD100Sub.TabIndex = 36
        Me.radD100Sub.UseVisualStyleBackColor = True
        '
        'radD20Sub
        '
        Me.radD20Sub.AutoSize = True
        Me.radD20Sub.Location = New System.Drawing.Point(241, 336)
        Me.radD20Sub.Name = "radD20Sub"
        Me.radD20Sub.Size = New System.Drawing.Size(21, 20)
        Me.radD20Sub.TabIndex = 35
        Me.radD20Sub.UseVisualStyleBackColor = True
        '
        'radD12Sub
        '
        Me.radD12Sub.AutoSize = True
        Me.radD12Sub.Location = New System.Drawing.Point(241, 288)
        Me.radD12Sub.Name = "radD12Sub"
        Me.radD12Sub.Size = New System.Drawing.Size(21, 20)
        Me.radD12Sub.TabIndex = 34
        Me.radD12Sub.UseVisualStyleBackColor = True
        '
        'radD10Sub
        '
        Me.radD10Sub.AutoSize = True
        Me.radD10Sub.Location = New System.Drawing.Point(241, 242)
        Me.radD10Sub.Name = "radD10Sub"
        Me.radD10Sub.Size = New System.Drawing.Size(21, 20)
        Me.radD10Sub.TabIndex = 33
        Me.radD10Sub.UseVisualStyleBackColor = True
        '
        'radD8Sub
        '
        Me.radD8Sub.AutoSize = True
        Me.radD8Sub.Location = New System.Drawing.Point(241, 200)
        Me.radD8Sub.Name = "radD8Sub"
        Me.radD8Sub.Size = New System.Drawing.Size(21, 20)
        Me.radD8Sub.TabIndex = 32
        Me.radD8Sub.UseVisualStyleBackColor = True
        '
        'radD6Sub
        '
        Me.radD6Sub.AutoSize = True
        Me.radD6Sub.Location = New System.Drawing.Point(241, 158)
        Me.radD6Sub.Name = "radD6Sub"
        Me.radD6Sub.Size = New System.Drawing.Size(21, 20)
        Me.radD6Sub.TabIndex = 31
        Me.radD6Sub.UseVisualStyleBackColor = True
        '
        'radD4Sub
        '
        Me.radD4Sub.AutoSize = True
        Me.radD4Sub.Location = New System.Drawing.Point(241, 112)
        Me.radD4Sub.Name = "radD4Sub"
        Me.radD4Sub.Size = New System.Drawing.Size(21, 20)
        Me.radD4Sub.TabIndex = 30
        Me.radD4Sub.UseVisualStyleBackColor = True
        '
        'radD100Plus
        '
        Me.radD100Plus.AutoSize = True
        Me.radD100Plus.Location = New System.Drawing.Point(199, 379)
        Me.radD100Plus.Name = "radD100Plus"
        Me.radD100Plus.Size = New System.Drawing.Size(21, 20)
        Me.radD100Plus.TabIndex = 29
        Me.radD100Plus.UseVisualStyleBackColor = True
        '
        'radD20Plus
        '
        Me.radD20Plus.AutoSize = True
        Me.radD20Plus.Location = New System.Drawing.Point(199, 336)
        Me.radD20Plus.Name = "radD20Plus"
        Me.radD20Plus.Size = New System.Drawing.Size(21, 20)
        Me.radD20Plus.TabIndex = 28
        Me.radD20Plus.UseVisualStyleBackColor = True
        '
        'radD12Plus
        '
        Me.radD12Plus.AutoSize = True
        Me.radD12Plus.Location = New System.Drawing.Point(199, 288)
        Me.radD12Plus.Name = "radD12Plus"
        Me.radD12Plus.Size = New System.Drawing.Size(21, 20)
        Me.radD12Plus.TabIndex = 27
        Me.radD12Plus.UseVisualStyleBackColor = True
        '
        'radD10Plus
        '
        Me.radD10Plus.AutoSize = True
        Me.radD10Plus.Location = New System.Drawing.Point(199, 242)
        Me.radD10Plus.Name = "radD10Plus"
        Me.radD10Plus.Size = New System.Drawing.Size(21, 20)
        Me.radD10Plus.TabIndex = 26
        Me.radD10Plus.UseVisualStyleBackColor = True
        '
        'RadD8Plus
        '
        Me.RadD8Plus.AutoSize = True
        Me.RadD8Plus.Location = New System.Drawing.Point(199, 200)
        Me.RadD8Plus.Name = "RadD8Plus"
        Me.RadD8Plus.Size = New System.Drawing.Size(21, 20)
        Me.RadD8Plus.TabIndex = 25
        Me.RadD8Plus.UseVisualStyleBackColor = True
        '
        'radD6Plus
        '
        Me.radD6Plus.AutoSize = True
        Me.radD6Plus.Location = New System.Drawing.Point(199, 158)
        Me.radD6Plus.Name = "radD6Plus"
        Me.radD6Plus.Size = New System.Drawing.Size(21, 20)
        Me.radD6Plus.TabIndex = 24
        Me.radD6Plus.UseVisualStyleBackColor = True
        '
        'radD4Plus
        '
        Me.radD4Plus.AutoSize = True
        Me.radD4Plus.Location = New System.Drawing.Point(199, 112)
        Me.radD4Plus.Name = "radD4Plus"
        Me.radD4Plus.Size = New System.Drawing.Size(21, 20)
        Me.radD4Plus.TabIndex = 23
        Me.radD4Plus.UseVisualStyleBackColor = True
        '
        'lblDivider
        '
        Me.lblDivider.AutoSize = True
        Me.lblDivider.Location = New System.Drawing.Point(9, 67)
        Me.lblDivider.Name = "lblDivider"
        Me.lblDivider.Size = New System.Drawing.Size(783, 20)
        Me.lblDivider.TabIndex = 22
        Me.lblDivider.Text = "=================================================================================" &
    "=====" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'btnRollD100
        '
        Me.btnRollD100.Location = New System.Drawing.Point(422, 369)
        Me.btnRollD100.Name = "btnRollD100"
        Me.btnRollD100.Size = New System.Drawing.Size(86, 34)
        Me.btnRollD100.TabIndex = 21
        Me.btnRollD100.Text = "Roll"
        Me.btnRollD100.UseVisualStyleBackColor = True
        '
        'btnRollD20
        '
        Me.btnRollD20.Location = New System.Drawing.Point(422, 326)
        Me.btnRollD20.Name = "btnRollD20"
        Me.btnRollD20.Size = New System.Drawing.Size(86, 34)
        Me.btnRollD20.TabIndex = 20
        Me.btnRollD20.Text = "Roll"
        Me.btnRollD20.UseVisualStyleBackColor = True
        '
        'btnRollD12
        '
        Me.btnRollD12.Location = New System.Drawing.Point(422, 276)
        Me.btnRollD12.Name = "btnRollD12"
        Me.btnRollD12.Size = New System.Drawing.Size(86, 34)
        Me.btnRollD12.TabIndex = 19
        Me.btnRollD12.Text = "Roll"
        Me.btnRollD12.UseVisualStyleBackColor = True
        '
        'btnRollD10
        '
        Me.btnRollD10.Location = New System.Drawing.Point(422, 230)
        Me.btnRollD10.Name = "btnRollD10"
        Me.btnRollD10.Size = New System.Drawing.Size(86, 34)
        Me.btnRollD10.TabIndex = 18
        Me.btnRollD10.Text = "Roll"
        Me.btnRollD10.UseVisualStyleBackColor = True
        '
        'btnRollD8
        '
        Me.btnRollD8.Location = New System.Drawing.Point(422, 188)
        Me.btnRollD8.Name = "btnRollD8"
        Me.btnRollD8.Size = New System.Drawing.Size(86, 34)
        Me.btnRollD8.TabIndex = 17
        Me.btnRollD8.Text = "Roll"
        Me.btnRollD8.UseVisualStyleBackColor = True
        '
        'btnRollD6
        '
        Me.btnRollD6.Location = New System.Drawing.Point(422, 143)
        Me.btnRollD6.Name = "btnRollD6"
        Me.btnRollD6.Size = New System.Drawing.Size(86, 34)
        Me.btnRollD6.TabIndex = 16
        Me.btnRollD6.Text = "Roll"
        Me.btnRollD6.UseVisualStyleBackColor = True
        '
        'btnRollD4
        '
        Me.btnRollD4.Location = New System.Drawing.Point(422, 102)
        Me.btnRollD4.Name = "btnRollD4"
        Me.btnRollD4.Size = New System.Drawing.Size(86, 34)
        Me.btnRollD4.TabIndex = 15
        Me.btnRollD4.Text = "Roll"
        Me.btnRollD4.UseVisualStyleBackColor = True
        '
        'lblD100
        '
        Me.lblD100.AutoSize = True
        Me.lblD100.Location = New System.Drawing.Point(122, 379)
        Me.lblD100.Name = "lblD100"
        Me.lblD100.Size = New System.Drawing.Size(45, 20)
        Me.lblD100.TabIndex = 14
        Me.lblD100.Text = "d100"
        '
        'lblD20
        '
        Me.lblD20.AutoSize = True
        Me.lblD20.Location = New System.Drawing.Point(122, 336)
        Me.lblD20.Name = "lblD20"
        Me.lblD20.Size = New System.Drawing.Size(36, 20)
        Me.lblD20.TabIndex = 13
        Me.lblD20.Text = "d20"
        '
        'lblD12
        '
        Me.lblD12.AutoSize = True
        Me.lblD12.Location = New System.Drawing.Point(122, 288)
        Me.lblD12.Name = "lblD12"
        Me.lblD12.Size = New System.Drawing.Size(36, 20)
        Me.lblD12.TabIndex = 12
        Me.lblD12.Text = "d12"
        '
        'lblD10
        '
        Me.lblD10.AutoSize = True
        Me.lblD10.Location = New System.Drawing.Point(122, 242)
        Me.lblD10.Name = "lblD10"
        Me.lblD10.Size = New System.Drawing.Size(36, 20)
        Me.lblD10.TabIndex = 11
        Me.lblD10.Text = "d10"
        '
        'lblD8
        '
        Me.lblD8.AutoSize = True
        Me.lblD8.Location = New System.Drawing.Point(122, 200)
        Me.lblD8.Name = "lblD8"
        Me.lblD8.Size = New System.Drawing.Size(27, 20)
        Me.lblD8.TabIndex = 10
        Me.lblD8.Text = "d8"
        '
        'lblD6
        '
        Me.lblD6.AutoSize = True
        Me.lblD6.Location = New System.Drawing.Point(122, 155)
        Me.lblD6.Name = "lblD6"
        Me.lblD6.Size = New System.Drawing.Size(27, 20)
        Me.lblD6.TabIndex = 9
        Me.lblD6.Text = "d6"
        '
        'lblD4
        '
        Me.lblD4.AutoSize = True
        Me.lblD4.Location = New System.Drawing.Point(122, 114)
        Me.lblD4.Name = "lblD4"
        Me.lblD4.Size = New System.Drawing.Size(27, 20)
        Me.lblD4.TabIndex = 8
        Me.lblD4.Text = "d4"
        '
        'txtD100
        '
        Me.txtD100.Location = New System.Drawing.Point(16, 373)
        Me.txtD100.Name = "txtD100"
        Me.txtD100.Size = New System.Drawing.Size(100, 26)
        Me.txtD100.TabIndex = 7
        Me.txtD100.Text = "1"
        Me.txtD100.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD20
        '
        Me.txtD20.Location = New System.Drawing.Point(16, 330)
        Me.txtD20.Name = "txtD20"
        Me.txtD20.Size = New System.Drawing.Size(100, 26)
        Me.txtD20.TabIndex = 6
        Me.txtD20.Text = "1"
        Me.txtD20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD12
        '
        Me.txtD12.Location = New System.Drawing.Point(16, 282)
        Me.txtD12.Name = "txtD12"
        Me.txtD12.Size = New System.Drawing.Size(100, 26)
        Me.txtD12.TabIndex = 5
        Me.txtD12.Text = "1"
        Me.txtD12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD10
        '
        Me.txtD10.Location = New System.Drawing.Point(16, 236)
        Me.txtD10.Name = "txtD10"
        Me.txtD10.Size = New System.Drawing.Size(100, 26)
        Me.txtD10.TabIndex = 4
        Me.txtD10.Text = "1"
        Me.txtD10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD8
        '
        Me.txtD8.Location = New System.Drawing.Point(16, 194)
        Me.txtD8.Name = "txtD8"
        Me.txtD8.Size = New System.Drawing.Size(100, 26)
        Me.txtD8.TabIndex = 3
        Me.txtD8.Text = "1"
        Me.txtD8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD6
        '
        Me.txtD6.Location = New System.Drawing.Point(16, 149)
        Me.txtD6.Name = "txtD6"
        Me.txtD6.Size = New System.Drawing.Size(100, 26)
        Me.txtD6.TabIndex = 2
        Me.txtD6.Text = "1"
        Me.txtD6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtD4
        '
        Me.txtD4.Location = New System.Drawing.Point(16, 108)
        Me.txtD4.Name = "txtD4"
        Me.txtD4.Size = New System.Drawing.Size(100, 26)
        Me.txtD4.TabIndex = 1
        Me.txtD4.Text = "1"
        Me.txtD4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'frmInitiativeTracker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(830, 611)
        Me.Controls.Add(Me.tabMain)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmInitiativeTracker"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Roll for Initiative"
        Me.tabMain.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblName As Label
    Friend WithEvents lblInitiative As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtInitiative As TextBox
    Friend WithEvents btnAddToList As Button
    Friend WithEvents btnBeginBattle As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblOutput As Label
    Friend WithEvents btnNext As Button
    Friend WithEvents btnEndBattle As Button
    Friend WithEvents tabMain As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Button31 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Button36 As Button
    Friend WithEvents Button37 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button39 As Button
    Friend WithEvents Button40 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents txtHP10 As TextBox
    Friend WithEvents txtHPName10 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtHP9 As TextBox
    Friend WithEvents txtHPName9 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtHP8 As TextBox
    Friend WithEvents txtHPName8 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtHP7 As TextBox
    Friend WithEvents txtHPName7 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtHP6 As TextBox
    Friend WithEvents txtHPName6 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtHP5 As TextBox
    Friend WithEvents txtHPName5 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtHP4 As TextBox
    Friend WithEvents txtHPName4 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtHP3 As TextBox
    Friend WithEvents txtHPName3 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtHP2 As TextBox
    Friend WithEvents txtHPName2 As TextBox
    Friend WithEvents lbl01 As Label
    Friend WithEvents txtHP1 As TextBox
    Friend WithEvents txtHPName1 As TextBox
    Friend WithEvents lblHealth As Label
    Friend WithEvents lblNameHealth As Label
    Friend WithEvents btnClearHP As Button
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents radD100Sub As RadioButton
    Friend WithEvents radD20Sub As RadioButton
    Friend WithEvents radD12Sub As RadioButton
    Friend WithEvents radD10Sub As RadioButton
    Friend WithEvents radD8Sub As RadioButton
    Friend WithEvents radD6Sub As RadioButton
    Friend WithEvents radD4Sub As RadioButton
    Friend WithEvents radD100Plus As RadioButton
    Friend WithEvents radD20Plus As RadioButton
    Friend WithEvents radD12Plus As RadioButton
    Friend WithEvents radD10Plus As RadioButton
    Friend WithEvents RadD8Plus As RadioButton
    Friend WithEvents radD6Plus As RadioButton
    Friend WithEvents radD4Plus As RadioButton
    Friend WithEvents lblDivider As Label
    Friend WithEvents btnRollD100 As Button
    Friend WithEvents btnRollD20 As Button
    Friend WithEvents btnRollD12 As Button
    Friend WithEvents btnRollD10 As Button
    Friend WithEvents btnRollD8 As Button
    Friend WithEvents btnRollD6 As Button
    Friend WithEvents btnRollD4 As Button
    Friend WithEvents lblD100 As Label
    Friend WithEvents lblD20 As Label
    Friend WithEvents lblD12 As Label
    Friend WithEvents lblD10 As Label
    Friend WithEvents lblD8 As Label
    Friend WithEvents lblD6 As Label
    Friend WithEvents lblD4 As Label
    Friend WithEvents txtD100 As TextBox
    Friend WithEvents txtD20 As TextBox
    Friend WithEvents txtD12 As TextBox
    Friend WithEvents txtD10 As TextBox
    Friend WithEvents txtD8 As TextBox
    Friend WithEvents txtD6 As TextBox
    Friend WithEvents txtD4 As TextBox
    Friend WithEvents lblMod As Label
    Friend WithEvents lblSubMod As Label
    Friend WithEvents lblAddMod As Label
    Friend WithEvents lblDice As Label
    Friend WithEvents lblOutputDice As Label
    Friend WithEvents txtD100Mod As TextBox
    Friend WithEvents txtD20Mod As TextBox
    Friend WithEvents txtD12Mod As TextBox
    Friend WithEvents txtD10Mod As TextBox
    Friend WithEvents txtD8Mod As TextBox
    Friend WithEvents txtD6Mod As TextBox
    Friend WithEvents txtD4Mod As TextBox
    Friend WithEvents lblResults As Label
    Friend WithEvents btnExitHP As Button
    Friend WithEvents btnClearDice As Button
    Friend WithEvents btnExitDice As Button
End Class
