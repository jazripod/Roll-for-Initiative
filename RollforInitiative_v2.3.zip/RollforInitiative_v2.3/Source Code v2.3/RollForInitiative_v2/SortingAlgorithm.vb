﻿'Public Class SortingAlgorithm
'    Private NumberList As New ArrayList
'    Private SortedList As New ArrayList
'    Private mIndex As Integer = -1
'    Private mIndexDecrease As Integer
'    Private mSortedListIndex As Integer = -1
'    Private mGreatesNumber As Integer

'    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
'        Dim Add As Integer = Integer.Parse(TEXTBOX_NAME.Text)
'        mIndex = mIndex + 1
'        NumberList.Add(Add)

'    End Sub

'    Private Sub btnSort_Click(sender As Object, e As EventArgs) Handles btnSort.Click
'        mGreatesNumber = 0
'        mIndexDecrease = mIndex

'        For Ctr = 0 To mIndexDecrease Step 1
'            For i = 0 To mIndexDecrease Step 1
'                If NumberList(i) > mGreatesNumber Then
'                    mGreatesNumber = NumberList(i)
'                End If
'            Next

'            SortedList.Add(mGreatesNumber)
'            NumberList.Remove(mGreatesNumber)
'            mIndexDecrease = mIndexDecrease - 1

'            mGreatesNumber = 0
'        Next
'    End Sub

'    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
'        mSortedListIndex = mSortedListIndex + 1

'        If mSortedListIndex > mIndex Then
'            mSortedListIndex = 0
'            OUTPUT Text
'        Else
'            OUTPUT Text
'        End If
'    End Sub
'End Class
